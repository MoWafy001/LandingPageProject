# Landing Page Project

A navigation bar is built dynamically based on the number of sections in the page.
when a button is clicked in the nav bar, it scrolls to the corresponding section.
when you scroll, the section in the view is highlighted.